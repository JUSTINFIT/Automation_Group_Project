package frameworks;

import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class KDTReadExcelClass 
{
	public void readExcel(WebDriver driver) throws InterruptedException, Exception
	{
		FileInputStream file=new FileInputStream("./KDT_NopCommerce.xlsx");
		XSSFWorkbook w= new XSSFWorkbook(file);
		XSSFSheet s= w.getSheet("KeywordDriven");

		int rowSize=s.getLastRowNum();
		System.out.println("No Of Keywords: "+rowSize);
		KDTOperationalClass o=new KDTOperationalClass();

		for(int i=1;i<=rowSize;i++)
		{
			String key=s.getRow(i).getCell(0).getStringCellValue();
			System.out.println(key);

			if(key.equals("OpenURL"))
			{
				o.getUrl(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("MaximizeBrowser"))
			{
				o.maximizeBrowser(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("ClickLogin"))
			{
				o.clickLogin(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("EnterUsername"))
			{
				o.enterUsername(driver, "justinkvarghese666@gmail.com");
				Thread.sleep(2000);
			}
			else if(key.equals("EnterPassword"))
			{
				o.enterPassword(driver, "justin6666");
				Thread.sleep(2000);
			}
			else if(key.equals("ClickOnLogin"))
			{
				o.clickOnLogin(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("ClickOnLogout"))
			{
				o.clickOnLogout(driver);
				Thread.sleep(2000);
			}
			else if(key.equals("CloseBrowser"))
			{
				o.closeBrowser(driver);
			}
		}
	}

}
