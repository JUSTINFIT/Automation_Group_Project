package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NopCommerce_MainClass {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Automation Testing\\Eclipse Backup\\NopCommerce\\Browser Extension\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        
        NopCommerce nc= new NopCommerce();	
        nc.maximizeBrowser(driver);
	    nc.getUrl(driver);
	    Thread.sleep(2000);
	    nc.clickLogin(driver);
	    Thread.sleep(2000);
	    nc.enterUsername(driver,"justinkvarghese666@gmail.com");
	    Thread.sleep(2000);
	    nc.enterPassword(driver,"justin6666");
	    Thread.sleep(2000);
	    nc.clickOnLogin(driver);
	    Thread.sleep(2000);
	    nc.clickOnLogout(driver);
	    Thread.sleep(2000);
	    nc.closeBrowser(driver);
	}

}
