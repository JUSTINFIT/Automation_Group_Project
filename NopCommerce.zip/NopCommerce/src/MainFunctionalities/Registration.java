package MainFunctionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration {


public static void main(String[] args) throws Exception {
	System.setProperty("webdriver.chrome.driver", "D:\\Automation Testing\\Eclipse Backup\\NopCommerce\\Browser Extension\\chromedriver.exe");
	  WebDriver driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().deleteAllCookies();
	  driver.get("https://demo.nopcommerce.com/"); 
	  Thread.sleep(2000);
	  // click on the registration 
	  driver.findElement(By.xpath("//a[@class='ico-register']")).click();
	  
	  // select the radio button 
	  WebElement RadiobButton=driver.findElement(By.xpath("//label[@for='gender-male']"));
	  boolean alreadychecked= RadiobButton.isSelected();
	  if(alreadychecked==false)
	  {
		  RadiobButton.click(); 
	  }
	  
	 //Enter first name
	  driver.findElement(By.xpath("//input[@id='FirstName']")).sendKeys("Justin");
	  Thread.sleep(2000);
	  //Enter Last Name
	  driver.findElement(By.xpath("//input[@id='LastName']")).sendKeys("Varghese");
	  Thread.sleep(2000);
	  
	  // handle dropdown for birth date foe day
	    Select s= new Select(driver.findElement(By.xpath("//select[@name='DateOfBirthDay']")));
	    s.selectByIndex(10);
	    Thread.sleep(2000);
	    // handle dropedown for birth date of month
	    Select s1= new Select(driver.findElement(By.xpath("//select[@name='DateOfBirthMonth']")));
	    s1.selectByVisibleText("October");
	    Thread.sleep(2000);
	    // handle dropDown for birthdate of year
	    Select s2=new Select(driver.findElement(By.xpath("//select[@name='DateOfBirthYear']")));
	    s2.selectByValue("1998");
	    
	    // enter the email
	    driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("justin6666@gmail.com");
	    Thread.sleep(2000);
	    // enter the company details
	    driver.findElement(By.xpath("//input[@id='Company']")).sendKeys("Best Software Testing");
	    Thread.sleep(2000);
	    // check the option
	    driver.findElement(By.xpath("//label[@for='Newsletter']")).click();
	    Thread.sleep(2000);
	    
	    // enter the password
	    driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("justin6666");
	    Thread.sleep(2000);
	    //enter the confirm password
	    driver.findElement(By.xpath("//input[@id='ConfirmPassword']")).sendKeys("justin6666");
	    Thread.sleep(2000);
	    
	    // click on registration
	    driver.findElement(By.xpath("//button[@id='register-button']")).click();
	    Thread.sleep(2000);

	 
		}

}
