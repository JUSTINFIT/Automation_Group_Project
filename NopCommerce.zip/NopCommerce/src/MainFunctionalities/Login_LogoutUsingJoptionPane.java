package MainFunctionalities;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_LogoutUsingJoptionPane {
	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "D:\\Automation Testing\\Eclipse Backup\\NopCommerce\\Browser Extension\\chromedriver.exe");
		  WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
	  	driver.manage().deleteAllCookies();	
		driver.get("https://demo.nopcommerce.com/");
		// click on log in link
		driver.findElement(By.xpath("//a[@class='ico-login']")).click();
		// enter the email
		String em=JOptionPane.showInputDialog("Enter Email");
		driver.findElement(By.xpath("//input[@id='Email']")).sendKeys(em);
		Thread.sleep(2000);
		// enter the password
		String pwd=JOptionPane.showInputDialog("Enter Password");
		driver.findElement(By.xpath("//input[@id='Password']")).sendKeys(pwd);
		Thread.sleep(2000);
		// click on login button
		driver.findElement(By.xpath("//button[normalize-space()='Log in']")).click();
		Thread.sleep(2000);
		
		// log out the page
		driver.findElement(By.xpath("//a[@class='ico-logout']")).click();
		Thread.sleep(2000);
		// close the driver
		driver.close();
	

	}

}
