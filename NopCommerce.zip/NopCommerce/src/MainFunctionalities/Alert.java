package MainFunctionalities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alert {

	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Automation Testing\\Eclipse Backup\\NopCommerce\\Browser Extension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://demo.nopcommerce.com/");
		Thread.sleep(2000);

		//click on login 
		driver.findElement(By.xpath("/html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		Thread.sleep(2000);

		//Username
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("justinkvarghese666@gmail.com");
		Thread.sleep(2000);

		//Password
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("justin6666");
		Thread.sleep(6000);

		//login
		driver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();
		Thread.sleep(2000);

		//Alert:
		//Confirmation Alert:
		//Step 1: Display Alert message on Console
		System.out.println("confirmation alert message: "+driver.switchTo().alert().getText());
		//Step 2: Click on Ok button
		driver.switchTo().alert().accept();
		// driver.switchTo().alert().dismiss(); >> click on cancel button. Because at a time we cannot use ok and cancel.

		//Simple Alert
		System.out.println("simple alert message: "+driver.switchTo().alert().getText());
		driver.switchTo().alert().accept();


	}

}
